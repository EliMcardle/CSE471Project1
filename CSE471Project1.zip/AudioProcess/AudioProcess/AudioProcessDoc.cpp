
// AudioProcessDoc.cpp : implementation of the CAudioProcessDoc class
//

#include "pch.h"
#include <algorithm>

#include "msxml2.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "AudioProcess.h"
#endif

#include "AudioProcessDoc.h"
#include "ProcessDlg.h"
#include "CNote.h"

#include <vector>
#include <fstream>

#include <propkey.h>
#include <sstream>
#include <string>

using namespace std;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void CAudioProcessDoc::OnProcessCopy()
{
   // Call to open the processing output
   if(!ProcessBegin())
      return;

   short audio[2];

   for(int i=0;  i<SampleFrames();  i++)
   {                 
      ProcessReadFrame(audio);

      audio[0] = short(audio[0] * m_amplitude);
      audio[1] = short(audio[1] * m_amplitude);

      ProcessWriteFrame(audio);

      // The progress control
      if(!ProcessProgress(double(i) / SampleFrames()))
         break;
   }

   
   // Call to close the generator output
   ProcessEnd();
}



// CAudioProcessDoc

IMPLEMENT_DYNCREATE(CAudioProcessDoc, CDocument)

BEGIN_MESSAGE_MAP(CAudioProcessDoc, CDocument)
	ON_COMMAND(ID_PROCESS_FILEOUTPUT, &CAudioProcessDoc::OnProcessFileoutput)
	ON_COMMAND(ID_PROCESS_AUDIOOUTPUT, &CAudioProcessDoc::OnProcessAudiooutput)
	ON_UPDATE_COMMAND_UI(ID_PROCESS_FILEOUTPUT, &CAudioProcessDoc::OnUpdateProcessFileoutput)
	ON_UPDATE_COMMAND_UI(ID_PROCESS_AUDIOOUTPUT, &CAudioProcessDoc::OnUpdateProcessAudiooutput)
	ON_COMMAND(ID_PROCESS_COPY, &CAudioProcessDoc::OnProcessCopy)
	ON_COMMAND(ID_PROCESS_PARAMETERS, &CAudioProcessDoc::OnProcessParameters)
	ON_COMMAND(ID_PROCESS_RAMP, &CAudioProcessDoc::OnProcessRamp)
	ON_COMMAND(ID_PROCESS_RAMPIN, &CAudioProcessDoc::OnProcessRampin)
	ON_COMMAND(ID_PROCESS_TREMOLO, &CAudioProcessDoc::OnProcessTremolo)
	ON_COMMAND(ID_PROCESS_SLOW, &CAudioProcessDoc::OnProcessSlow)
	ON_COMMAND(ID_PROCESS_FAST, &CAudioProcessDoc::OnProcessFast)
	ON_COMMAND(ID_PROCESS_BACKWARDS, &CAudioProcessDoc::OnProcessBackwards)
	ON_COMMAND(ID_FILE_OPEN32791, &CAudioProcessDoc::OnFileOpen32791)
	ON_COMMAND(ID_FILE_OPENSCORE, &CAudioProcessDoc::OnFileOpenscore)
	ON_COMMAND(ID_PROCESS_LIMITER, &CAudioProcessDoc::OnProcessLimiter)
END_MESSAGE_MAP()




// CAudioProcessDoc construction/destruction

CAudioProcessDoc::CAudioProcessDoc()
{
   m_audiooutput = true;
   m_fileoutput = false;

   m_numChannels = 2;
   m_sampleRate = 44100.;
   m_numSampleFrames = 0;
   m_amplitude = 1.0;

   m_bpm = 120;
   m_secperbeat = 0.5;
   m_beatspermeasure = 4;
}

CAudioProcessDoc::~CAudioProcessDoc()
{
}

BOOL CAudioProcessDoc::OnNewDocument()
{
	return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CAudioProcessDoc serialization

void CAudioProcessDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CAudioProcessDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CAudioProcessDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CAudioProcessDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CAudioProcessDoc diagnostics

#ifdef _DEBUG
void CAudioProcessDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAudioProcessDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CAudioProcessDoc commands


BOOL CAudioProcessDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	if(!m_wavein.Open(lpszPathName))
		return FALSE;

	m_sampleRate = m_wavein.SampleRate();
	m_numChannels = m_wavein.NumChannels();
	m_numSampleFrames = m_wavein.NumSampleFrames();
   
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
//
// The following functions manage the audio processing process, 
// directing output to the waveform buffer, file, and/or audio 
// output.  
//
/////////////////////////////////////////////////////////////////////////////


//
// Name :        CAudioProcessDoc::ProcessBegin()
// Description : This function starts the audio processing process.
//               It opens the waveform storage, opens the file
//               if file output is requested, and opens the 
//               audio output if audio output is requested.
//               Be sure to call EndProcess() when done.
// Returns :     true if successful...
//

bool CAudioProcessDoc::ProcessBegin()
{
    m_wavein.Rewind();

	// 
	// Waveform storage
	//

	m_waveformBuffer.Start(NumChannels(), SampleRate());

    if(m_fileoutput)
    {
      if(!OpenProcessFile(m_waveout))
         return false;
    }

   ProgressBegin(this);

   if(m_audiooutput)
   {
      m_soundstream.SetChannels(NumChannels());
      m_soundstream.SetSampleRate(int(SampleRate()));

      m_soundstream.Open(((CAudioProcessApp *)AfxGetApp())->DirSound());
   }

   return true;
}


//
// Name :        CAudioProcessDoc::ProcessReadFrame()
// Description : Read a frame of input from the current audio file.
//

void CAudioProcessDoc::ProcessReadFrame(short *p_frame)
{
   m_wavein.ReadFrame(p_frame);
}


//
// Name :        CAudioProcessDoc::ProcessWriteFrame()
// Description : Write a frame of output to the current generation device.
//

void CAudioProcessDoc::ProcessWriteFrame(short *p_frame)
{
    m_waveformBuffer.Frame(p_frame);

   if(m_fileoutput)
      m_waveout.WriteFrame(p_frame);

   if(m_audiooutput)
      m_soundstream.WriteFrame(p_frame);
}


//
// Name :        CAudioProcessDoc::ProcessEnd()
// Description : End the generation process.
//

void CAudioProcessDoc::ProcessEnd()
{
    m_waveformBuffer.End();

   if(m_fileoutput)
      m_waveout.close();

   if(m_audiooutput)
      m_soundstream.Close();

   ProgressEnd(this);


}

//
// Name :        CAudioProcessDoc::OpenProcessFile()
// Description : This function opens the audio file for output.
// Returns :     true if successful...
//

bool CAudioProcessDoc::OpenProcessFile(CWaveOut &p_wave)
{
   p_wave.NumChannels(m_numChannels);
   p_wave.SampleRate(m_sampleRate);

	static WCHAR BASED_CODE szFilter[] = L"Wave Files (*.wav)|*.wav|All Files (*.*)|*.*||";

	CFileDialog dlg(FALSE, L".wav", NULL, 0, szFilter, NULL);
	if(dlg.DoModal() != IDOK)
      return false;

    p_wave.open(dlg.GetPathName());
   if(p_wave.fail())
      return false;

   return true;
}



void CAudioProcessDoc::OnProcessFileoutput()
{
	m_fileoutput = !m_fileoutput;
}


void CAudioProcessDoc::OnProcessAudiooutput()
{
   m_audiooutput = !m_audiooutput;
}


void CAudioProcessDoc::OnUpdateProcessFileoutput(CCmdUI *pCmdUI)
{
   pCmdUI->SetCheck(m_fileoutput);	
}


void CAudioProcessDoc::OnUpdateProcessAudiooutput(CCmdUI *pCmdUI)
{
   pCmdUI->SetCheck(m_audiooutput);	
}



void CAudioProcessDoc::OnProcessParameters()
{
   CProcessDlg dlg;
   
   dlg.m_amplitude = m_amplitude;

   if(dlg.DoModal() == IDOK)
   {
      m_amplitude = dlg.m_amplitude;
   }
}


void CAudioProcessDoc::OnProcessRamp()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	short audio[2];
	// Keep track of time
	double time = 0;

	for (int i = 0; i < SampleFrames(); i++, time += 1.0 / SampleRate())
	{
		ProcessReadFrame(audio);

		double ramp;
		if (time < 0.5)
		{
			ramp = time / 0.5;
		}
		else
		{
			ramp = 1;
		}

		audio[0] = short(audio[0] * m_amplitude * ramp);
		audio[1] = short(audio[1] * m_amplitude * ramp);

		ProcessWriteFrame(audio);

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}


	// Call to close the generator output
	ProcessEnd();
}

short RangeBound(double d)
{
	if (d > 32767)
		return 32767;
	if (d < -32768)
		return -32768;
	return short(d);
}

void CAudioProcessDoc::OnProcessRampin()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	short audio[2];
	double daudio[2];
	// Keep track of time
	double time = 0;

	for (int i = 0; i < SampleFrames(); i++, time += 1.0 / SampleRate())
	{
		ProcessReadFrame(audio);

		double ramp;
		if (time < 0.7)
		{
			ramp = (time / 0.7) * 2;
		}
		else
		{
			ramp = 2;
		}

		int totalTime = SampleFrames() / SampleRate();

		if (time >= totalTime - 0.9)
		{
			ramp = (totalTime - time)/0.9;
		}

		if (ramp <0 ) {
			ramp = 0;
		}

		daudio[0] = double(audio[0] * m_amplitude * ramp);
		daudio[1] = double(audio[1] * m_amplitude * ramp);

		audio[0] = RangeBound(daudio[0]);
		audio[1] = RangeBound(daudio[1]);

		ProcessWriteFrame(audio);

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}


	// Call to close the generator output
	ProcessEnd();
}


void CAudioProcessDoc::OnProcessTremolo()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	short audio[2];
	// Keep track of time
	double time = 0;

	for (int i = 0; i < SampleFrames(); i++, time += 1.0 / SampleRate())
	{
		ProcessReadFrame(audio);

		double newAmplitude = 1 + (0.5 * sin(3.5 * 2 * 3.141592 * time));

		audio[0] = short(audio[0] * newAmplitude);
		audio[1] = short(audio[1] * newAmplitude);

		ProcessWriteFrame(audio);

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}


	// Call to close the generator output
	ProcessEnd();
}


void CAudioProcessDoc::OnProcessSlow()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	short audio[2];
	// Keep track of time
	double time = 0;
	short previousAudio[2];
	previousAudio[0] = 0;

	for (int i = 0; i < SampleFrames(); i++, time += 1.0 / SampleRate())
	{
		ProcessReadFrame(audio);

		if (previousAudio[0] != 0) {
			audio[0] = (previousAudio[0]+ short(audio[0] * m_amplitude))/2;
			audio[1] = (previousAudio[1] + short(audio[1] * m_amplitude)) / 2;
			ProcessWriteFrame(audio);
		}

		audio[0] = short(audio[0] * m_amplitude);
		audio[1] = short(audio[1] * m_amplitude);

		ProcessWriteFrame(audio);

		previousAudio[0] = audio[0];
		previousAudio[1] = audio[1];

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}


	// Call to close the generator output
	ProcessEnd();
}


void CAudioProcessDoc::OnProcessFast()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	SampleRate();

	short audio[2];

	for (int i = 0; i < SampleFrames(); i++)
	{
		ProcessReadFrame(audio);

		audio[0] = short(audio[0] * m_amplitude);
		audio[1] = short(audio[1] * m_amplitude);

		ProcessWriteFrame(audio);

		ProcessReadFrame(audio);

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}


	// Call to close the generator output
	ProcessEnd();
}


void CAudioProcessDoc::OnProcessBackwards()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	std::vector<vector<short>> audioList;

	short audio[2];
	std::vector<short> tempAudioList;

	for (int i = 0; i < SampleFrames(); i++)
	{
		ProcessReadFrame(audio);

		audio[0] = short(audio[0] * m_amplitude);
		audio[1] = short(audio[1] * m_amplitude);
		tempAudioList.push_back(audio[0]);
		tempAudioList.push_back(audio[1]);
		audioList.push_back(tempAudioList);
		tempAudioList.clear();

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}

	std::vector<vector<short>> reversedAudioList;

	//reverse the list
	for (int i = audioList.size() - 1; i >= 0; i--) {
		reversedAudioList.push_back(audioList[i]);
	}

	for (int i = 0; i < reversedAudioList.size(); i++) {

		audio[0] = reversedAudioList[i][0];
		audio[1] = reversedAudioList[i][1];
		ProcessWriteFrame(audio);
	}


	// Call to close the generator output
	ProcessEnd();
}

void CAudioProcessDoc::OnFileOpen32791()
{
	static WCHAR BASED_CODE szFilter[] = L"Filter Transfer Equation Files (*.tran)|*.tran|All Files (*.*)|*.*||";

	CFileDialog dlg(TRUE, L".tran", NULL, 0, szFilter, NULL);
	if (dlg.DoModal() != IDOK)
		return;

	ifstream filt(dlg.GetPathName());
	if (filt.fail())
	{
		AfxMessageBox(L"Failed to open filter transfer equation file");
		return;
	}

	if (filt.is_open()) 
	{
		std::string line;
		bool starty = false;
		getline(filt, line);

		while (getline(filt, line)) 
		{
			if (line == "") {
				getline(filt, line);
				starty = true;
				continue;
			}

			string delay;
			string weight;
			int tempIndex = 0;

			for (int i = 0; i < line.size(); i++) 
			{
				tempIndex = i;
				if (line[i] == ' ')
				{
					break;
				}
				delay += line[i];
			}

			for (int i = tempIndex; i < line.size(); i++)
			{
				weight += line[i];
			}

			if (!starty)
			{
				FTerm xInput;
				xInput.m_delay = stoi(delay);
				stringstream ss;
				float weightNum;
				ss << weight;
				ss >> weightNum;
				xInput.m_weight = weightNum;
				m_xterms.push_back(xInput);
			}
			if (starty)
			{
				FTerm yInput;
				yInput.m_delay = stoi(delay);
				stringstream ss;
				float weightNum;
				ss << weight;
				ss >> weightNum;
				yInput.m_weight = weightNum;
				m_yterms.push_back(yInput);
			}
		}
		starty = false;
		filt.close();
	}
}


void CAudioProcessDoc::OnFileOpenscore()
{
	static WCHAR BASED_CODE szFilter[] = L"Score files (*.score)|*.score|All Files (*.*)|*.*||";

	CFileDialog dlg(TRUE, L".score", NULL, 0, szFilter, NULL);
	if (dlg.DoModal() != IDOK)
		return;

	OpenScore(dlg.GetPathName());
}

void CAudioProcessDoc::OpenScore(CString& filename)
{
	
	//
	// Create an XML document
	//

	CComPtr<IXMLDOMDocument>  pXMLDoc;
	bool succeeded = SUCCEEDED(CoCreateInstance(CLSID_DOMDocument, NULL, CLSCTX_INPROC_SERVER,
		IID_IXMLDOMDocument, (void**)&pXMLDoc));
	if (!succeeded)
	{
		AfxMessageBox(L"Failed to create an XML document to use");
		return;
	}

	// Open the XML document
	VARIANT_BOOL ok;
	succeeded = SUCCEEDED(pXMLDoc->load(CComVariant(filename), &ok));
	if (!succeeded || ok == VARIANT_FALSE)
	{
		AfxMessageBox(L"Failed to open XML score file");
		return;
	}

	//
	// Traverse the XML document in memory!!!!
	// Top level tag is <score>
	//

	CComPtr<IXMLDOMNode> node;
	pXMLDoc->get_firstChild(&node);
	for (; node != NULL; NextNode(node))
	{
		// Get the name of the node
		CComBSTR nodeName;
		node->get_nodeName(&nodeName);

		if (nodeName == "score")
		{
			XmlLoadScore(node);
		}
	}

	//sort(m_notes.begin(), m_notes.end());

}

void CAudioProcessDoc::XmlLoadScore(IXMLDOMNode* xml)
{
	// Get a list of all attribute nodes and the
	// length of that list
	CComPtr<IXMLDOMNamedNodeMap> attributes;
	xml->get_attributes(&attributes);
	long len;
	attributes->get_length(&len);

	// Loop over the list of attributes
	for (int i = 0; i < len; i++)
	{
		// Get attribute i
		CComPtr<IXMLDOMNode> attrib;
		attributes->get_item(i, &attrib);

		// Get the name of the attribute
		CComBSTR name;
		attrib->get_nodeName(&name);

		// Get the value of the attribute.  A CComVariant is a variable
		// that can have any type. It loads the attribute value as a
		// string (UNICODE), but we can then change it to an integer 
		// (VT_I4) or double (VT_R8) using the ChangeType function 
		// and then read its integer or double value from a member variable.
		CComVariant value;
		attrib->get_nodeValue(&value);

		if (name == L"bpm")
		{
			value.ChangeType(VT_R8);
			m_bpm = value.dblVal;
			m_secperbeat = 1 / (m_bpm / 60);
		}
		else if (name == L"beatspermeasure")
		{
			value.ChangeType(VT_I4);
			m_beatspermeasure = value.intVal;
		}

	}


	CComPtr<IXMLDOMNode> node;
	xml->get_firstChild(&node);
	for (; node != NULL; NextNode(node))
	{
		// Get the name of the node
		CComBSTR name;
		node->get_nodeName(&name);

		if (name == L"instrument")
		{
			XmlLoadInstrument(node);
		}
		if (name == "duration")
		{
			int i = 0;
		}
	}
}

void CAudioProcessDoc::XmlLoadInstrument(IXMLDOMNode* xml)
{
	wstring instrument = L"";

	// Get a list of all attribute nodes and the
	// length of that list
	CComPtr<IXMLDOMNamedNodeMap> attributes;
	xml->get_attributes(&attributes);
	long len;
	attributes->get_length(&len);

	// Loop over the list of attributes
	for (int i = 0; i < len; i++)
	{
		// Get attribute i
		CComPtr<IXMLDOMNode> attrib;
		attributes->get_item(i, &attrib);

		// Get the name of the attribute
		CComBSTR name;
		attrib->get_nodeName(&name);

		// Get the value of the attribute.  
		CComVariant value;
		attrib->get_nodeValue(&value);

		if (name == "instrument")
		{
			
			instrument = value.bstrVal;

			if (instrument == L"default") {
				OnProcessCopy();
			}
			if (instrument == L"limiter") {
				OnProcessLimiter();
			}
		}

	}


	CComPtr<IXMLDOMNode> node;
	xml->get_firstChild(&node);
	for (; node != NULL; NextNode(node))
	{
		// Get the name of the node
		CComBSTR name;
		node->get_nodeName(&name);

		if (name == L"note")
		{
			XmlLoadNote(node, instrument);
		}
	}
}

void CAudioProcessDoc::XmlLoadNote(IXMLDOMNode* xml, std::wstring& instrument)
{
	//m_notes.push_back(CNote());
	//m_notes.back().XmlLoad(xml, instrument);
}

void CAudioProcessDoc::OnProcessLimiter()
{
	// Call to open the processing output
	if (!ProcessBegin())
		return;

	short audio[2];

	short previousAudio0 = 0;
	short previousAudio1 = 0;

	for (int i = 0; i < SampleFrames(); i++)
	{
		ProcessReadFrame(audio);

		audio[0] = short(audio[0] * m_amplitude);
		audio[1] = short(audio[1] * m_amplitude);


		if (audio[0] < 500 && audio[0] > -500) {
			audio[0] *= 1.3f;
		}
		else if (audio[0] > 3000 || audio[0] < -3000) {
			audio[0] /= 1.3f;
		}

		if (audio[1] < 500 && audio[1] > -500) {
			audio[1] *= 1.3f;
		}
		else if (audio[1] > 3000 || audio[1] < -3000) {
			audio[1] /= 1.3f;
		}

		ProcessWriteFrame(audio);

		// The progress control
		if (!ProcessProgress(double(i) / SampleFrames()))
			break;
	}


	// Call to close the generator output
	ProcessEnd();
}

#pragma comment(lib, "msxml2.lib")
